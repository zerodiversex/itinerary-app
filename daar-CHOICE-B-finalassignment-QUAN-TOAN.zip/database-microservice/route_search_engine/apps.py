from django.apps import AppConfig


class RouteSearchEngineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'route_search_engine'
